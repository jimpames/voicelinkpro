document.getElementById('callBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('panic.html') });
  window.close();
});