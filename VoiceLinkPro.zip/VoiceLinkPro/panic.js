// Tab switching
document.querySelectorAll('.tabs button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.fake-app').forEach(app => app.classList.remove('active'));
    const selectedApp = document.getElementById(btn.dataset.app);
    if (selectedApp) selectedApp.classList.add('active');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

// "End call" exits panic mode
document.getElementById('exitBtn').addEventListener('click', () => {
  window.close();
});

// Escape key fallback
document.addEventListener('keydown', e => {
  if (e.key === "Escape") window.close();
});

// Live ticking call timer
let callSeconds = 0;
const timerEl = document.getElementById('callTimer');
setInterval(() => {
  callSeconds++;
  const mins = String(Math.floor(callSeconds / 60)).padStart(2, '0');
  const secs = String(callSeconds % 60).padStart(2, '0');
  timerEl.textContent = `${mins}:${secs}`;
}, 1000);